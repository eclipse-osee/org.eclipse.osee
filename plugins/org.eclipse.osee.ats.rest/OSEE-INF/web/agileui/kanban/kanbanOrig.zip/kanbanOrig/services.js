/*
 * Copyright (c) 2015 Robert Bosch Engineering and Business Solutions Private Ltd India. All rights reserved. This program and
 * the accompanying materials are made available under the terms of the Eclipse Public License v1.0 which accompanies
 * this distribution, and is available at http://www.eclipse.org/legal/epl-v10.html
 */

/*
 * Registers kanbanApp.services as angular service module
 */
angular.module('kanbanApp.services', []).factory('taskCreator',
		function($http) {

			var taskCreator = {};

			/*
			 * Fetches tasks data for kanban
			 */
			taskCreator.getTasks = function(teamId, projectId) {
				/*
				 * return $http({ method : 'GET', url : 'data/tasks.json'});
				 */
				return $http({
					method : 'GET',
					url : '../../agile/teams/' + teamId + "/sprints/1902187009"
				});
			}

			/*
			 * Fetches projects data for kanban
			 */
			taskCreator.getProjects = function() {
				return $http({
					method : 'GET',
					url : 'data/projects.json'
				});
			}

			/*
			 * Fetches teams data for kanban
			 */
			taskCreator.getTeams = function(projectId) {
				/*
				 * return $http({ method: 'GET', url: 'data/teams.json' });
				 */
				return $http({
					method : 'GET',
					url : '../../agile/teams'
				});
			}

			return taskCreator;

			/*
			 * Updates task transition for kanban Note: In this sample currently
			 * not used
			 */
			taskCreator.updateTask = function(obj) {
				var _data = obj;
				return $http({
					method : 'POST',
					data : _data,
					url : 'rest/kanban/taskUpdate'
				})
			}
		});
