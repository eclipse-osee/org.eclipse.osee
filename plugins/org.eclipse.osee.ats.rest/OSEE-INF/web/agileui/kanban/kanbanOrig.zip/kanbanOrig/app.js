/*
 * Copyright (c) 2015 Robert Bosch Engineering and Business Solutions Private Ltd India. All rights reserved. This program and
 * the accompanying materials are made available under the terms of the Eclipse Public License v1.0 which accompanies
 * this distribution, and is available at http://www.eclipse.org/legal/epl-v10.html
 */

/*
 *  Registers kanbanApp as top level root module for ngApp
 *  Controllers and services dependencies are injected
 */
angular.module('kanbanApp', [ 'kanbanApp.controllers', 'kanbanApp.services' ]);